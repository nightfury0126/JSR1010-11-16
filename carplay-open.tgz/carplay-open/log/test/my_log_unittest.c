#include "stdio.h"
#include "my_log.h"

int main(int argc, char *argv[])
{

    printf("-----------------------\n");
    printf("版本号: V1.2.30\n");
    printf("build date: 2024.4.13\n");
    printf("-----------------------\n");
    LOG_INFO("1111");
    LOG_WARN("打东边来了个喇嘛");
    LOG_ERROR("2222");
    LOG_USER("abcabc");

    return 0;
}
