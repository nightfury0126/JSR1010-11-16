cmake_minimum_required (VERSION 3.10)

aux_source_directory(. TEST_SRCS)

add_executable(${MODULE_NAME}_test ${TEST_SRCS})

target_link_libraries(${MODULE_NAME}_test ${MODULE_NAME})
