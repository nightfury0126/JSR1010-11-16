cmake_minimum_required (VERSION 3.10)

set(MODULE_NAME "mylog")

aux_source_directory(. MODULE_SRCS)

include_directories(${APP_DIR}/include)

add_library(${MODULE_NAME} STATIC ${MODULE_SRCS})

add_subdirectory(test)
