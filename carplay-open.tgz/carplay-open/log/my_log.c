#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include "my_log.h"

#define PRId32   "d"

static sr_log_print_g_cb_t custom_print_cb;
static sr_log_level_t custom_log_level;

typedef struct {
    const char * fmt;
    va_list * va;
} sr_vaformat_t;

void set_log_level(sr_log_level_t level)
{
    custom_log_level = level;
    LOG_INFO("设置日志打印等级: %d", custom_log_level);

}

/**
 * Register custom print/write function to call when a log is added.
 * It can format its "File path", "Line number" and "Description" as required
 * and send the formatted log message to a console or serial port.
 * @param print_cb a function pointer to print a log
 */
void sr_log_register_print_cb(sr_log_print_g_cb_t print_cb)
{
    custom_print_cb = print_cb;
}
static void get_current_timestamp(char *buffer)
{
    struct timeval tv;
    struct tm *tm_info;
    gettimeofday(&tv, NULL);

    tm_info = localtime(&tv.tv_sec);
    strftime(buffer, 24, "%Y-%m-%d %H:%M:%S", tm_info);

    // Append milliseconds
    size_t len = strlen(buffer);
    snprintf(buffer + len, 24 - len, ".%03ld", tv.tv_usec / 1000);
}
/**
 * Add a log
 * @param level the level of log. (From `sr_log_level_t` enum)
 * @param file name of the file when the log added
 * @param line line number in the source code where the log added
 * @param func name of the function when the log added
 * @param format printf-like format string
 * @param ... parameters for `format`
 */
void _sr_log_add(sr_log_level_t level, const char * file, int line, const char * func, const char * format, ...)
{
    if(level >= _LOG_LEVEL_NUM) return; /*Invalid level*/

    static uint32_t last_log_time = 0;

    // if(level >= LOG_LEVEL) {
    if (level >= custom_log_level) {
        va_list args;
        va_start(args, format);

        /*Use only the file name not the path*/
        size_t p;
        for(p = strlen(file); p > 0; p--) {
            if(file[p] == '/' || file[p] == '\\') {
                p++;    /*Skip the slash*/
                break;
            }
        }

        //uint32_t t = sr_tick_get();
        static const char * lvl_prefix[] = {"\033[1;36mTrace\033[0m",
											"\033[1;32mInfo\033[0m",
											"\033[1;33mWarn\033[0m",
											"\033[1;31mError\033[0m",
											"\033[1;34mUser\033[0m"};
        char t[24] = {0};
        get_current_timestamp(&t);

#if LOG_PRINTF
        printf("[%s]\t(%s)\t %s: ",
               lvl_prefix[level], t, func);
        vprintf(format, args);
        printf(" \t(in %s line #%d)\n", &file[p], line);
#else
        if(custom_print_cb) {
            char buf[512];
#if SPRINTF_CUSTOM
            char msg[256];
            sr_vsnprintf(msg, sizeof(msg), format, args);
            sr_snprintf(buf, sizeof(buf), "[%s]\t(%" PRId32 ".%03" PRId32 ", +%" PRId32 ")\t %s: %s \t(in %s line #%d)\n",
                        lvl_prefix[level], t / 1000, t % 1000, t - last_log_time, func, msg, &file[p], line);
#else
            sr_vaformat_t vaf = {format, &args};
            snprintf(buf, sizeof(buf), "[%s]\t(%" PRId32 ".%03" PRId32 ", +%" PRId32 ")\t %s: %pV \t(in %s line #%d)\n",
                        lvl_prefix[level], t / 1000, t % 1000, t - last_log_time, func, (void *)&vaf, &file[p], line);
#endif
            custom_print_cb(buf);
        }
#endif

        last_log_time = t;
        va_end(args);
    }
}

void sr_log(const char * format, ...)
{
    if(LOG_LEVEL >= LOG_LEVEL_NONE) return; /* disable log */

    va_list args;
    va_start(args, format);

#if LOG_PRINTF
    vprintf(format, args);
#else
    if(custom_print_cb) {
        char buf[512];
#if SPRINTF_CUSTOM
        sr_vsnprintf(buf, sizeof(buf), format, args);
#else
        sr_vaformat_t vaf = {format, &args};
        snprintf(buf, sizeof(buf), "%pV", (void *)&vaf);
#endif
        custom_print_cb(buf);
    }
#endif

    va_end(args);
}


int log_file_init(void)
{
    /* 日志等级文件 */
    if (access(LOG_LEVEL_FILE_PATH, F_OK) != 0) {
        FILE *file = fopen(LOG_LEVEL_FILE_PATH, "w");
        if (file) {
            fputs("4\n", file);
            set_log_level(4);
            fclose(file);
        } else {
            printf("### log level file open error!\n");
        }
    } else {
        FILE *fp = popen("cat /mnt/UDISK/log_level.txt", "r");
        if (fp != NULL) {
            int result = fgetc(fp);
            set_log_level(result - 48);
            pclose(fp);
        }
    }
}
