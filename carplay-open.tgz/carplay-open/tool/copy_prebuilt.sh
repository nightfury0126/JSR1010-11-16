#!/bin/bash
# 把当前源码仓的闭源引擎更新到同级开放仓的 prebuilt/ 目录。
# 用法: tool/copy_prebuilt.sh [开放仓目录名或绝对路径]（默认 carplay-open）
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "$(readlink -f "$0")")" && pwd)
SRC_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
TARGET_NAME="${1:-carplay-open}"

if [[ "$TARGET_NAME" = /* ]]; then
    DEST_DIR="$TARGET_NAME"
else
    DEST_DIR="$(cd "$SRC_DIR/.." && pwd)/$TARGET_NAME"
fi

SOURCE_SO="$SRC_DIR/out/libs/libcarplay_media.so.1.0.0"
SOURCE_EXE="$SRC_DIR/out/carplay"
MANIFEST="$DEST_DIR/prebuilt/ENGINE_MANIFEST.json"
DEST_LIB_DIR="$DEST_DIR/prebuilt/lib"
DEST_INC_DIR="$DEST_DIR/prebuilt/include"
DEST_LIB="$DEST_LIB_DIR/libcarplay_media.so.1.0.0"

if [ ! -f "$SOURCE_SO" ] || [ ! -f "$SOURCE_EXE" ]; then
    echo "ERROR: 未找到编译产物，请先在源码仓执行 ./build.sh make"
    echo "       $SOURCE_SO"
    echo "       $SOURCE_EXE"
    exit 1
fi

if [ ! -f "$MANIFEST" ]; then
    echo "ERROR: 目标不是开放仓或缺少 manifest: $MANIFEST"
    exit 1
fi

if [ ! -d "$DEST_LIB_DIR" ]; then
    echo "ERROR: 目标开放仓缺少 prebuilt/lib: $DEST_LIB_DIR"
    exit 1
fi

if [ ! -f "$SRC_DIR/include/my_config.h" ]; then
    echo "ERROR: 源码仓缺少 include/my_config.h"
    exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
    echo "ERROR: 未找到 jq，无法更新 ENGINE_MANIFEST.json"
    exit 1
fi

SOURCE_CFG_HASH=$(sha256sum "$SRC_DIR/include/my_config.h" | awk '{print $1}')
if [ -f "$DEST_DIR/include/my_config.h" ]; then
    DEST_CFG_HASH=$(sha256sum "$DEST_DIR/include/my_config.h" | awk '{print $1}')
    if [ "$SOURCE_CFG_HASH" != "$DEST_CFG_HASH" ]; then
        echo "ERROR: 源码仓与开放仓的 include/my_config.h 不一致"
        echo "       源码仓: $SOURCE_CFG_HASH"
        echo "       开放仓: $DEST_CFG_HASH"
        echo "       该引擎与开放仓的 sensor/LCD 配置不匹配，已停止更新"
        exit 1
    fi
else
    echo "WARN: 开放仓缺少 include/my_config.h，无法校验配置一致性"
fi

TMP_LIB=$(mktemp)
trap 'rm -f "$TMP_LIB"' EXIT
cp "$SOURCE_SO" "$TMP_LIB"

STRIP_CMD="${STRIP:-}"
if [ -z "$STRIP_CMD" ]; then
    STRIP_CMD=$(command -v arm-openwrt-linux-muslgnueabi-strip || true)
fi
if [ -z "$STRIP_CMD" ]; then
    STRIP_CMD=$(command -v strip || true)
fi
if [ -z "$STRIP_CMD" ]; then
    echo "ERROR: 未找到 strip 工具"
    exit 1
fi
"$STRIP_CMD" --strip-unneeded "$TMP_LIB"

echo "==> ABI 校验"
if ! python3 "$SRC_DIR/autobuild/scripts/check_abi.py" --so "$TMP_LIB" --exe "$SOURCE_EXE"; then
    echo "ERROR: ABI 校验失败，开放仓未更新"
    exit 1
fi

ENGINE_VERSION=$("$SRC_DIR/tool/media_version.sh" "$TMP_LIB")
ENGINE_SHA256=$(sha256sum "$TMP_LIB" | awk '{print $1}')
ENGINE_SHORT_COMMIT=$(printf '%s' "$ENGINE_VERSION" | sed -E 's/^[^+]*\+abi[^-]*-[^-]*-([0-9a-f]+).*/\1/')
GIT_COMMIT=$(git -C "$SRC_DIR" rev-parse "$ENGINE_SHORT_COMMIT" 2>/dev/null || printf '%s' "$ENGINE_SHORT_COMMIT")
HEAD_SHORT=$(git -C "$SRC_DIR" rev-parse --short=12 HEAD 2>/dev/null || true)

if [ -n "$HEAD_SHORT" ] && [ "$HEAD_SHORT" != "$ENGINE_SHORT_COMMIT" ]; then
    echo "WARN: 当前引擎不是 HEAD ($HEAD_SHORT) 构建的，引擎提交为 $ENGINE_SHORT_COMMIT"
fi

PUBLIC_HEADERS=(
    "$SRC_DIR/include/my_media.h"
    "$SRC_DIR/include/my_message.h"
    "$SRC_DIR/media/my_media_comm.h"
    "$SRC_DIR/media/middle_ware/media_file_play.h"
    "$SRC_DIR/media/middle_ware/mid_list.h"
)
for header in "${PUBLIC_HEADERS[@]}"; do
    if [ ! -f "$header" ]; then
        echo "ERROR: 公共头不存在: $header"
        exit 1
    fi
done

install -m 0755 "$TMP_LIB" "$DEST_LIB"
ln -sfn "libcarplay_media.so.1.0.0" "$DEST_LIB_DIR/libcarplay_media.so.1"
ln -sfn "libcarplay_media.so.1" "$DEST_LIB_DIR/libcarplay_media.so"

mkdir -p "$DEST_INC_DIR"
for header in "${PUBLIC_HEADERS[@]}"; do
    install -m 0644 "$header" "$DEST_INC_DIR/"
done

MANIFEST_TMP=$(mktemp)
jq \
    --arg version "$ENGINE_VERSION" \
    --arg sha256 "$ENGINE_SHA256" \
    --arg commit "$GIT_COMMIT" \
    --arg config_sha256 "$SOURCE_CFG_HASH" \
    '.engine.version = $version
     | .engine.sha256 = $sha256
     | .engine.source_git_commit = $commit
     | del(.engine.source_git_dirty)
     | .config.my_config_sha256 = $config_sha256' \
    "$MANIFEST" > "$MANIFEST_TMP"
install -m 0644 "$MANIFEST_TMP" "$MANIFEST"
rm -f "$MANIFEST_TMP"

echo "==> 完成"
echo "引擎版本: $ENGINE_VERSION"
echo "引擎 sha256: $ENGINE_SHA256"
echo "开放仓: $DEST_DIR"
