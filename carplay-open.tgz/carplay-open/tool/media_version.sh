#!/bin/sh
# 读取 libcarplay_media.so 内嵌的构建版本。
# 用法: tool/media_version.sh <path/to/libcarplay_media.so>
set -e

so=${1:?usage: $0 <libcarplay_media.so>}

version=$(strings "$so" | sed -n 's/^CARPLAY_MEDIA_VERSION=//p' | head -n 1)
if [ -z "$version" ]; then
    echo "未找到 CARPLAY_MEDIA_VERSION 标记: $so" >&2
    exit 1
fi

printf '%s\n' "$version"
