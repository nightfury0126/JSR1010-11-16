deps_config := \
	extra/Configs/Config.ui \
	extra/Configs/Config.bsp \
	extra/Configs/Config.lcd \
	extra/Configs/Config.media \
	extra/Configs/Config.sensor \
	extra/Configs/Config.version \
	extra/Configs/Config.in

.config include/bits/uClibc_config.h: $(deps_config)

$(deps_config):
