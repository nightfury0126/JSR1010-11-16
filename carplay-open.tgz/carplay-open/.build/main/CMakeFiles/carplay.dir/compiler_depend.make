# Empty compiler generated dependencies file for carplay.
# This may be replaced when dependencies are built.
