file(REMOVE_RECURSE
  "../../out/carplay"
  "../../out/carplay.pdb"
  "CMakeFiles/carplay.dir/my_main.c.o"
  "CMakeFiles/carplay.dir/my_main.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/carplay.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
