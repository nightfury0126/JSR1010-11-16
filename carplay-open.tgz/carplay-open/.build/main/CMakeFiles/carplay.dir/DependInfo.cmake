
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/starriver/workspace/carplay-open/main/my_main.c" "main/CMakeFiles/carplay.dir/my_main.c.o" "gcc" "main/CMakeFiles/carplay.dir/my_main.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/starriver/workspace/carplay-open/.build/ui/CMakeFiles/ui.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/bsp/CMakeFiles/bsp.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/audio/CMakeFiles/audio.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/upgrade/CMakeFiles/upgrade.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/media/CMakeFiles/media_open.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/sys/CMakeFiles/carplay_sys.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/ui/m90/CMakeFiles/carplayui.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/ui/lvgl/V553/lvgl/CMakeFiles/lvgl.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/ui/lvgl/V553/lvgl/lv_drivers/CMakeFiles/lv_drivers.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
