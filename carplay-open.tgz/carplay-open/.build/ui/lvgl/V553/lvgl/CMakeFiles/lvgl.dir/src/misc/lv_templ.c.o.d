ui/lvgl/V553/lvgl/CMakeFiles/lvgl.dir/src/misc/lv_templ.c.o: \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/misc/lv_templ.c \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdc-predef.h
