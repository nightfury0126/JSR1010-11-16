ui/lvgl/V553/lvgl/CMakeFiles/lvgl.dir/src/extra/libs/sjpg/tjpgd.c.o: \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/libs/sjpg/tjpgd.c \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdc-predef.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/libs/sjpg/tjpgd.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/libs/sjpg/../../../lv_conf_internal.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdint.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/alltypes.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/stdint.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/libs/sjpg/../../../lv_conf_kconfig.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/lv_conf.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/libs/sjpg/tjpgdcnf.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/string.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/features.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/sys/glibc-types.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/sys/cdefs.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/strings.h
