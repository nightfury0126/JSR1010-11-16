file(REMOVE_RECURSE
  "../../../../../out/libs/liblvgl.a"
)
