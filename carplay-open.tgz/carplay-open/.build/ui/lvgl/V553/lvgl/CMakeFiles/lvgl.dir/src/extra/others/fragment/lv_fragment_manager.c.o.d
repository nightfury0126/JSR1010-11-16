ui/lvgl/V553/lvgl/CMakeFiles/lvgl.dir/src/extra/others/fragment/lv_fragment_manager.c.o: \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/others/fragment/lv_fragment_manager.c \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdc-predef.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/others/fragment/lv_fragment.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/others/fragment/../../../lv_conf_internal.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdint.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/alltypes.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/stdint.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/extra/others/fragment/../../../lv_conf_kconfig.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/lv_conf.h
