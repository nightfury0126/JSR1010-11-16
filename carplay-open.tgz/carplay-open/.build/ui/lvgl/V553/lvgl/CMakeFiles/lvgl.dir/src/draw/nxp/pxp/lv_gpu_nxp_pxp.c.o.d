ui/lvgl/V553/lvgl/CMakeFiles/lvgl.dir/src/draw/nxp/pxp/lv_gpu_nxp_pxp.c.o: \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp.c \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdc-predef.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/draw/nxp/pxp/lv_gpu_nxp_pxp.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/draw/nxp/pxp/../../../lv_conf_internal.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdint.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/alltypes.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/stdint.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/src/draw/nxp/pxp/../../../lv_conf_kconfig.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/lv_conf.h
