ui/lvgl/V553/lvgl/lv_drivers/CMakeFiles/lv_drivers.dir/gtkdrv/gtkdrv.c.o: \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/lv_drivers/gtkdrv/gtkdrv.c \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdc-predef.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/lv_drivers/gtkdrv/gtkdrv.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/lv_drivers/lv_drv_conf.h \
 /home/starriver/workspace/carplay-open/ui/lvgl/V553/lvgl/lv_conf.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/stdint.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/alltypes.h \
 /home/starriver/workspace/official-tina-open/prebuilt/gcc/linux-x86/arm/toolchain-sunxi-musl/toolchain/include/bits/stdint.h
