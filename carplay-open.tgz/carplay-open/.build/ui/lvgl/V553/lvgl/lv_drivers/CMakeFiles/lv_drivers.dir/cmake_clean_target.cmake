file(REMOVE_RECURSE
  "../../../../../../out/libs/liblv_drivers.a"
)
