# Empty compiler generated dependencies file for carplayui.
# This may be replaced when dependencies are built.
