file(REMOVE_RECURSE
  "../../../out/libs/libcarplayui.a"
)
