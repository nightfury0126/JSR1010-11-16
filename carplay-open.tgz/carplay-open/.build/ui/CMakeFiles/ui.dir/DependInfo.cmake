
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/starriver/workspace/carplay-open/ui/my_ui.c" "ui/CMakeFiles/ui.dir/my_ui.c.o" "gcc" "ui/CMakeFiles/ui.dir/my_ui.c.o.d"
  "/home/starriver/workspace/carplay-open/ui/ui_api.c" "ui/CMakeFiles/ui.dir/ui_api.c.o" "gcc" "ui/CMakeFiles/ui.dir/ui_api.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/starriver/workspace/carplay-open/.build/ui/m90/CMakeFiles/carplayui.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/ui/lvgl/V553/lvgl/CMakeFiles/lvgl.dir/DependInfo.cmake"
  "/home/starriver/workspace/carplay-open/.build/ui/lvgl/V553/lvgl/lv_drivers/CMakeFiles/lv_drivers.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
