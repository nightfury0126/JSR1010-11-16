file(REMOVE_RECURSE
  "../../out/libs/libui.a"
  "../../out/libs/libui.pdb"
  "CMakeFiles/ui.dir/my_ui.c.o"
  "CMakeFiles/ui.dir/my_ui.c.o.d"
  "CMakeFiles/ui.dir/ui_api.c.o"
  "CMakeFiles/ui.dir/ui_api.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/ui.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
