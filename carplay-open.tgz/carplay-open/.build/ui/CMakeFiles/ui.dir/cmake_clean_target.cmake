file(REMOVE_RECURSE
  "../../out/libs/libui.a"
)
